import React, { useEffect, useRef } from "react";
import anime from "animejs";

export default function Cart({ cart }) {
  const cartRef = useRef();

  useEffect(() => {
    anime({
      targets: cartRef.current,
      scale: [0.8, 1],
      opacity: [0, 1],
      duration: 500,
      easing: "easeOutBack",
    });
  }, [cart]);

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div
      ref={cartRef}
      className="backdrop-blur-sm bg-white/10 text-white p-5 rounded-xl mt-4 shadow-lg border border-neon"
    >
      <h2 className="text-xl font-bold mb-2 text-neon">Your Cart</h2>
      {cart.length === 0 ? (
        <p className="text-gray-300">Nothing added yet.</p>
      ) : (
        <>
          <ul className="mb-2">
            {cart.map((item, i) => (
              <li key={i} className="py-1 border-b border-gray-600">
                {item.name} - ₹{item.price}
              </li>
            ))}
          </ul>
          <p className="text-neon font-semibold">Total: ₹{total}</p>
          <button
            className="mt-3 w-full bg-neon text-black py-2 rounded-xl font-bold checkout-btn"
            onClick={() =>
              anime({
                targets: ".checkout-btn",
                rotate: [0, 2, -2, 0],
                duration: 600,
                easing: "easeInOutSine",
              })
            }
          >
            Checkout
          </button>
        </>
      )}
    </div>
  );
}
