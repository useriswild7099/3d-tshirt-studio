import React, { useState, useEffect } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, Stage } from "@react-three/drei";
import TShirtModel from "./TShirtModel";
import Cart from "./Cart";
import ProductList from "./ProductList";
import anime from "animejs";

export default function App() {
  const [cart, setCart] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);

  useEffect(() => {
    anime({
      targets: ".title",
      translateY: [-20, 0],
      opacity: [0, 1],
      duration: 1000,
      easing: "easeOutExpo",
    });
  }, []);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  return (
    <div className="dark bg-darkbg min-h-screen font-futuristic text-white">
      <div className="flex flex-col md:flex-row">
        <div className="w-full md:w-1/2 p-4">
          <h1 className="title text-4xl mb-4 text-center text-neon drop-shadow-md">
            3D T-Shirt Studio
          </h1>
          <div className="h-[500px] rounded-xl overflow-hidden shadow-2xl border border-neon">
            <Canvas camera={{ position: [0, 1.5, 2.5], fov: 50 }}>
              <Stage environment="night" intensity={0.9}>
                <TShirtModel color={selectedProduct?.color || "#ffffff"} />
              </Stage>
              <OrbitControls enablePan enableZoom />
            </Canvas>
          </div>
        </div>
        <div className="w-full md:w-1/2 p-4">
          <ProductList onSelect={setSelectedProduct} addToCart={addToCart} />
          <Cart cart={cart} />
        </div>
      </div>
    </div>
  );
}
