import React, { useEffect } from "react";
import anime from "animejs";

const products = [
  { id: 1, name: "Neon White", price: 499, color: "#ffffff" },
  { id: 2, name: "Vanta Black", price: 599, color: "#0a0a0a" },
  { id: 3, name: "Cyber Blue", price: 549, color: "#00bfff" },
  { id: 4, name: "Crimson Core", price: 599, color: "#dc143c" },
];

export default function ProductList({ onSelect, addToCart }) {
  useEffect(() => {
    anime({
      targets: ".product-card",
      opacity: [0, 1],
      translateY: [50, 0],
      delay: anime.stagger(150),
      duration: 800,
      easing: "easeOutExpo",
    });
  }, []);

  return (
    <div className="mb-6">
      <h2 className="text-2xl font-bold mb-3 text-neon">Products</h2>
      <div className="grid grid-cols-2 gap-4">
        {products.map((p) => (
          <div
            key={p.id}
            className="product-card bg-gradient-to-br from-[#1a1a2e] to-[#16213e] p-4 rounded-lg shadow-lg hover:scale-105 transition transform duration-300 border border-neon"
            onClick={() => onSelect(p)}
          >
            <div
              className="w-full h-24 rounded-lg mb-2 border border-white"
              style={{ backgroundColor: p.color }}
            />
            <h3 className="font-semibold">{p.name}</h3>
            <p className="text-sm text-gray-300">₹{p.price}</p>
            <button
              className="mt-2 bg-neon text-black px-3 py-1 rounded hover:bg-white transition"
              onClick={(e) => {
                e.stopPropagation();
                addToCart(p);
              }}
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
