import React from "react";
import { useGLTF } from "@react-three/drei";

export default function TShirtModel({ color }) {
  const { scene, materials } = useGLTF("/tshirt.glb");
  if (materials?.Material) materials.Material.color.set(color);
  return <primitive object={scene} scale={2} />;
}
