module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        neon: "#00ffff",
        darkbg: "#0f0f1a",
      },
      fontFamily: {
        futuristic: ["Orbitron", "sans-serif"],
      },
    },
  },
  plugins: [],
};
